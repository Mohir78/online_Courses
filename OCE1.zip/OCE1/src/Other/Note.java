package Other;

public class Note {
}
